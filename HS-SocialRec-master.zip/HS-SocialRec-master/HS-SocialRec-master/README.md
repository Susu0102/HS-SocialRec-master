# HS-SocialRec

This is an implemention for our Information Sciences paper based on Pytorch

[HS-SocialRec: A Study on Boosting Social Recommendations with Hard Negative Sampling in LightGCN]

by Ziping Sheng, Lai Wei

# Dataset
We provide Three datasets: [LastFM and Delicious](https://grouplens.org/datasets/hetrec-2011/) and [Ciao](https://www.cse.msu.edu/~tangjili/datasetcode/truststudy.htm).

# Example to run the codes
1. Environment: I have tested this code with python3.8 Pytorch=1.7.1 CUDA=11.0
2. Run HS-SocialRec

    `python main.py --model=HS-SocialRec --dataset=lastfm --decay=1e-4 --lr=0.01 --layer=3 --seed=2020 --topks="[10,20]" --recdim=128 --bpr_batch=2048`
